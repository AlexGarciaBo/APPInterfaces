package com.example.a21540743.appalejandro_garcia_boiza;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

/**
 * Created by 21540743 on 02/03/2018.
 */

public class SplashActivity{

}



